package carSales;

public class Sold extends AbstractEvent {

    private Long id;
    private Integer salesAmount;
    private Integer drivingYear;

    public Sold(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Integer getSalesAmount() {
        return salesAmount;
    }

    public void setSalesAmount(Integer salesAmount) {
        this.salesAmount = salesAmount;
    }
    
    public Integer getDrivingYear() {
        return drivingYear;
    }
    public void setDrivingYear(Integer drivingYear) {
        this.drivingYear = drivingYear;
    }
}
