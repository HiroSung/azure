package carSales;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CarSalesRepository extends PagingAndSortingRepository<CarSales, Long>{


}