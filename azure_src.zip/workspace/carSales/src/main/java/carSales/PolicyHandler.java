package carSales;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import carSales.config.kafka.KafkaProcessor;

@Service
public class PolicyHandler{

    @Autowired
    CarSalesRepository carSalesRepository;
    
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverInspected_InspectedResult(@Payload Inspected inspected){

    	if(inspected.isMe()){
            Optional<CarSales> carSalesOptional = carSalesRepository.findById(inspected.getCarId());
            carSalesOptional.get().setStatus(inspected.getStatus());
            carSalesRepository.save(carSalesOptional.get());
        }
    }

}
