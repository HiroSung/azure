package carSales;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import carSales.config.kafka.KafkaProcessor;

@Service
public class PolicyHandler{
	
	@Autowired
	InspectionRepository inspectionRepository;
    
    
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverBought_Inspect(@Payload Bought bought){

    	String status = "Inspected";
    	String reason = "";
    	

        if(bought.isMe()){

        	Integer carYear = bought.getCarYear();
        	Integer carAccidentCnt = bought.getCarAccidentCnt();
        	
        	if (carYear > 20) {
        		status = "Rejected";
        		reason = "Too Old";
        	}
        	else if (carYear <= 20 & carYear > 10) {
        		if ( carAccidentCnt > 5 ) {
            		status = "Rejected";
            		reason = "Old & Poor";        		
            	}
        	}
        	else {
        		if ( carAccidentCnt > 10 ) {
	        		status = "Rejected";
	        		reason = "Too Poor";
        		}
        	}
        	
        	Inspection inspection = new Inspection();
        	inspection.setCarId(bought.getId());
        	inspection.setStatus(status);
        	inspection.setReason(reason);        	
  	
        	inspectionRepository.save(inspection);
        	
        	Inspected inspected = new Inspected();
        	inspected.setCarId(inspection.getCarId());
        	inspected.setStatus(inspection.getStatus());
        	inspected.setReason(inspection.getReason());

        	ObjectMapper objectMapper = new ObjectMapper();
        	String json = null;

            try {
                json = objectMapper.writeValueAsString(inspected);
            } catch (JsonProcessingException e) {
                 e.printStackTrace();
            }

            KafkaProcessor kafkaProcessor = Application.applicationContext.getBean(KafkaProcessor.class);
            MessageChannel outputChannel = kafkaProcessor.outboundTopic();

            outputChannel.send(MessageBuilder
                    .withPayload(json)
                    .setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON)
                    .build()
            );
        }

    }

}
