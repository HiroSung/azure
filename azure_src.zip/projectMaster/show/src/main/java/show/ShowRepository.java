package show;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface ShowRepository extends PagingAndSortingRepository<Show, Long>{


}