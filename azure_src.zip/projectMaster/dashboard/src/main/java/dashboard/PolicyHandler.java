package dashboard;

import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    

}
